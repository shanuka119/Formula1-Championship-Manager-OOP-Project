interface ChampionshipManager {

}
